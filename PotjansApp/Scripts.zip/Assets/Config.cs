﻿using System.Globalization;

public class Config {

    public static string url = "http://www.fahrschule-potjans.de/2-theorie/theorie.html";
    public static string[] locations = {"Dülmen", "Buldern", "Hausdülmen"};
    public static CultureInfo mainCultureInfo = new CultureInfo("en-US");
}
